// src/code.ts

import { 
  ColorToken, 
  ColorUsage, 
  figmaRgbToHex, 
  determineColorFamily,
  colorDistance 
} from './utils/colorUtils';
import { 
  loadColorTokensFromVariables, 
  findClosestToken,
  findExactToken 
} from './utils/variableUtils';

// ============================================
// 타입 정의
// ============================================

interface ScanResult {
  totalNodes: number;
  totalColors: number;
  boundColors: number;
  unboundColors: number;
  ssotTokens: ColorToken[];
  violations: ColorUsage[];
}

// ============================================
// 전역 상태
// ============================================

let ssotTokens: ColorToken[] = [];

// ============================================
// UI 초기화
// ============================================

figma.showUI(__html__, { 
  width: 450, 
  height: 650,
  themeColors: true 
});

// ============================================
// 플러그인 시작 시 자동 스캔
// ============================================

(async () => {
  await runScan();
})();

// ============================================
// 메시지 핸들러
// ============================================

figma.ui.onmessage = async (msg: { type: string; payload?: any }) => {
  switch (msg.type) {
    case 'rescan':
      await runScan();
      break;
    case 'fix-color':
      await fixColor(msg.payload);
      break;
    case 'fix-all':
      await fixAllColors(msg.payload);
      break;
    case 'select-node':
      selectNode(msg.payload.nodeId);
      break;
    case 'close':
      figma.closePlugin();
      break;
  }
};

// ============================================
// 메인 스캔 함수
// ============================================

async function runScan(): Promise<void> {
  figma.ui.postMessage({ type: 'scan-start' });

  try {
    // Step 1: SSOT 색상 토큰 로드
    ssotTokens = await loadColorTokensFromVariables();

    if (ssotTokens.length === 0) {
      figma.ui.postMessage({ 
        type: 'scan-error', 
        error: 'Color Variables가 없습니다. 먼저 Color Variables를 설정해주세요.' 
      });
      return;
    }

    // Step 2: 현재 페이지 스캔
    const result = await scanCurrentPage();

    // Step 3: 결과 전송
    figma.ui.postMessage({ 
      type: 'scan-result', 
      data: result 
    });

  } catch (error) {
    figma.ui.postMessage({ 
      type: 'scan-error', 
      error: `스캔 중 오류 발생: ${error}` 
    });
  }
}

// ============================================
// 페이지 스캔
// ============================================

async function scanCurrentPage(): Promise<ScanResult> {
  const page = figma.currentPage;
  const violations: ColorUsage[] = [];
  let totalNodes = 0;
  let totalColors = 0;
  let boundColors = 0;
  let unboundColors = 0;

  // 재귀 탐색 함수
  function traverse(node: SceneNode): void {
    totalNodes++;

    // Fills 검사
    if ('fills' in node && node.fills !== figma.mixed && Array.isArray(node.fills)) {
      node.fills.forEach((fill, index) => {
        if (fill.type === 'SOLID' && fill.visible !== false) {
          totalColors++;
          const usage = analyzePaint(node, fill, 'fill', index);
          
          if (usage.isBoundToVariable) {
            boundColors++;
          } else {
            unboundColors++;
            violations.push(usage);
          }
        }
      });
    }

    // Strokes 검사
    if ('strokes' in node && Array.isArray(node.strokes)) {
      node.strokes.forEach((stroke, index) => {
        if (stroke.type === 'SOLID' && stroke.visible !== false) {
          totalColors++;
          const usage = analyzePaint(node, stroke, 'stroke', index);
          
          if (usage.isBoundToVariable) {
            boundColors++;
          } else {
            unboundColors++;
            violations.push(usage);
          }
        }
      });
    }

    // 자식 노드 탐색
    if ('children' in node) {
      for (const child of node.children) {
        traverse(child);
      }
    }
  }

  // Color Palette 프레임 제외하고 스캔
  for (const child of page.children) {
    // "컬러팔레트" 또는 "Color Palette" 프레임은 스캔 제외
    const name = child.name.toLowerCase();
    if (name.includes('컬러팔레트') || 
        name.includes('color palette') ||
        name.includes('color specimen') ||
        name.includes('색상') ||
        name.includes('pallette')) {
      continue;
    }
    traverse(child);
  }

  return {
    totalNodes,
    totalColors,
    boundColors,
    unboundColors,
    ssotTokens,
    violations,
  };
}

// ============================================
// Paint 분석
// ============================================

function analyzePaint(
  node: SceneNode,
  paint: SolidPaint,
  propertyType: 'fill' | 'stroke',
  paintIndex: number
): ColorUsage {
  const { r, g, b } = paint.color;
  const opacity = paint.opacity ?? 1;
  const hex = figmaRgbToHex(r, g, b);
  const rgb = {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255),
  };
  const family = determineColorFamily(rgb.r, rgb.g, rgb.b);

  // Variable 바인딩 확인
  let isBoundToVariable = false;
  let boundVariableName: string | undefined;

  if (paint.boundVariables?.color) {
    isBoundToVariable = true;
    const varId = paint.boundVariables.color.id;
    const variable = figma.variables.getVariableById(varId);
    boundVariableName = variable?.name;
  }

  // 추천 Variable 찾기 (바인딩 안 된 경우)
  let suggestion: ColorUsage['suggestion'];
  if (!isBoundToVariable) {
    // 먼저 정확히 일치하는 토큰 찾기
    const exactMatch = findExactToken(rgb, opacity, ssotTokens, 3);
    
    if (exactMatch) {
      suggestion = {
        variableId: exactMatch.variableId,
        name: exactMatch.name,
        hex: exactMatch.hex,
        distance: 0,
      };
    } else {
      // 같은 계열에서 가장 가까운 토큰 찾기
      const closest = findClosestToken(rgb, ssotTokens, true);
      if (closest) {
        suggestion = {
          variableId: closest.variableId,
          name: closest.name,
          hex: closest.hex,
          distance: Math.round(colorDistance(rgb, closest.rgb)),
        };
      }
    }
  }

  return {
    nodeId: node.id,
    nodeName: node.name,
    nodeType: node.type,
    propertyType,
    paintIndex,
    hex,
    rgb,
    opacity,
    family,
    isBoundToVariable,
    boundVariableName,
    suggestion,
  };
}

// ============================================
// 색상 수정
// ============================================

async function fixColor(payload: {
  nodeId: string;
  propertyType: 'fill' | 'stroke';
  paintIndex: number;
  variableId: string;
}): Promise<void> {
  const node = figma.getNodeById(payload.nodeId) as SceneNode;
  if (!node) {
    figma.notify('노드를 찾을 수 없습니다.', { error: true });
    return;
  }

  const variable = await figma.variables.getVariableByIdAsync(payload.variableId);
  if (!variable) {
    figma.notify('Variable을 찾을 수 없습니다.', { error: true });
    return;
  }

  try {
    if (payload.propertyType === 'fill' && 'fills' in node) {
      const fills = [...(node.fills as Paint[])];
      const paint = fills[payload.paintIndex];
      
      if (paint && paint.type === 'SOLID') {
        // Variable 바인딩
        const newPaint = figma.variables.setBoundVariableForPaint(
          paint,
          'color',
          variable
        );
        fills[payload.paintIndex] = newPaint;
        (node as GeometryMixin).fills = fills;
      }
    }

    if (payload.propertyType === 'stroke' && 'strokes' in node) {
      const strokes = [...(node.strokes as Paint[])];
      const paint = strokes[payload.paintIndex];
      
      if (paint && paint.type === 'SOLID') {
        const newPaint = figma.variables.setBoundVariableForPaint(
          paint,
          'color',
          variable
        );
        strokes[payload.paintIndex] = newPaint;
        (node as GeometryMixin).strokes = strokes;
      }
    }

    figma.notify(`✅ ${variable.name}으로 변경되었습니다.`);
    
    // 재스캔
    await runScan();

  } catch (error) {
    figma.notify('색상 변경 중 오류가 발생했습니다.', { error: true });
    console.error(error);
  }
}

// ============================================
// 모든 위반 색상 수정
// ============================================

async function fixAllColors(payload: {
  fixes: Array<{
    nodeId: string;
    propertyType: 'fill' | 'stroke';
    paintIndex: number;
    variableId: string;
  }>;
}): Promise<void> {
  let successCount = 0;
  let failCount = 0;

  for (const fix of payload.fixes) {
    const node = figma.getNodeById(fix.nodeId) as SceneNode;
    if (!node) {
      failCount++;
      continue;
    }

    const variable = await figma.variables.getVariableByIdAsync(fix.variableId);
    if (!variable) {
      failCount++;
      continue;
    }

    try {
      if (fix.propertyType === 'fill' && 'fills' in node) {
        const fills = [...(node.fills as Paint[])];
        const paint = fills[fix.paintIndex];
        
        if (paint && paint.type === 'SOLID') {
          const newPaint = figma.variables.setBoundVariableForPaint(
            paint,
            'color',
            variable
          );
          fills[fix.paintIndex] = newPaint;
          (node as GeometryMixin).fills = fills;
          successCount++;
        }
      }

      if (fix.propertyType === 'stroke' && 'strokes' in node) {
        const strokes = [...(node.strokes as Paint[])];
        const paint = strokes[fix.paintIndex];
        
        if (paint && paint.type === 'SOLID') {
          const newPaint = figma.variables.setBoundVariableForPaint(
            paint,
            'color',
            variable
          );
          strokes[fix.paintIndex] = newPaint;
          (node as GeometryMixin).strokes = strokes;
          successCount++;
        }
      }
    } catch (error) {
      failCount++;
      console.error(error);
    }
  }

  figma.notify(`✅ ${successCount}개 수정 완료` + (failCount > 0 ? `, ⚠️ ${failCount}개 실패` : ''));
  
  // 재스캔
  await runScan();
}

// ============================================
// 노드 선택
// ============================================

function selectNode(nodeId: string): void {
  const node = figma.getNodeById(nodeId) as SceneNode;
  if (node) {
    figma.currentPage.selection = [node];
    figma.viewport.scrollAndZoomIntoView([node]);
  }
}
