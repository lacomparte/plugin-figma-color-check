// src/ui.ts

// ============================================
// 타입 정의
// ============================================

interface ColorToken {
  variableId: string;
  name: string;
  hex: string;
  rgb: { r: number; g: number; b: number };
  opacity: number;
  family: string;
}

interface ColorUsage {
  nodeId: string;
  nodeName: string;
  nodeType: string;
  propertyType: 'fill' | 'stroke';
  paintIndex: number;
  hex: string;
  rgb: { r: number; g: number; b: number };
  opacity: number;
  family: string;
  isBoundToVariable: boolean;
  boundVariableName?: string;
  suggestion?: {
    variableId: string;
    name: string;
    hex: string;
    distance: number;
  };
}

interface ScanResult {
  totalNodes: number;
  totalColors: number;
  boundColors: number;
  unboundColors: number;
  ssotTokens: ColorToken[];
  violations: ColorUsage[];
}

// ============================================
// 상태
// ============================================

let currentViolations: ColorUsage[] = [];

// ============================================
// DOM 요소
// ============================================

const rescanBtn = document.getElementById('rescanBtn') as HTMLButtonElement;
const ssotInfo = document.getElementById('ssotInfo') as HTMLDivElement;
const ssotText = document.getElementById('ssotText') as HTMLSpanElement;
const stats = document.getElementById('stats') as HTMLDivElement;
const results = document.getElementById('results') as HTMLDivElement;
const footer = document.getElementById('footer') as HTMLDivElement;
const fixAllBtn = document.getElementById('fixAllBtn') as HTMLButtonElement;

// ============================================
// 이벤트 리스너
// ============================================

rescanBtn.addEventListener('click', () => {
  parent.postMessage({ pluginMessage: { type: 'rescan' } }, '*');
});

fixAllBtn.addEventListener('click', () => {
  if (currentViolations.length === 0) return;

  const fixes = currentViolations
    .filter(v => v.suggestion)
    .map(v => ({
      nodeId: v.nodeId,
      propertyType: v.propertyType,
      paintIndex: v.paintIndex,
      variableId: v.suggestion!.variableId,
    }));

  parent.postMessage({ 
    pluginMessage: { type: 'fix-all', payload: { fixes } } 
  }, '*');
});

// ============================================
// 메시지 핸들러
// ============================================

window.onmessage = (event) => {
  const msg = event.data.pluginMessage;

  switch (msg.type) {
    case 'scan-start':
      showLoading();
      break;

    case 'scan-result':
      renderResults(msg.data);
      break;

    case 'scan-error':
      showError(msg.error);
      break;
  }
};

// ============================================
// 렌더링 함수
// ============================================

function showLoading(): void {
  results.innerHTML = `
    <div class="loading-state">
      <div class="spinner"></div>
      <p>색상 검사 중...</p>
    </div>
  `;
  stats.style.display = 'none';
  ssotInfo.style.display = 'none';
  footer.style.display = 'none';
}

function showError(error: string): void {
  ssotInfo.className = 'ssot-info error';
  ssotInfo.style.display = 'flex';
  ssotText.textContent = error;

  results.innerHTML = `
    <div class="empty-state">
      <div class="empty-icon">⚠️</div>
      <div class="empty-title">오류 발생</div>
      <p>${error}</p>
    </div>
  `;
  
  stats.style.display = 'none';
  footer.style.display = 'none';
}

function renderResults(data: ScanResult): void {
  currentViolations = data.violations;

  // SSOT 정보 표시
  ssotInfo.className = 'ssot-info';
  ssotInfo.style.display = 'flex';
  ssotText.textContent = `${data.ssotTokens.length}개의 Color Variables를 SSOT로 사용 중`;

  // 통계 표시
  stats.style.display = 'grid';
  (document.getElementById('statTotal') as HTMLDivElement).textContent = 
    data.totalColors.toString();
  (document.getElementById('statBound') as HTMLDivElement).textContent = 
    data.boundColors.toString();
  (document.getElementById('statUnbound') as HTMLDivElement).textContent = 
    data.unboundColors.toString();
  
  const rate = data.totalColors > 0 
    ? Math.round((data.boundColors / data.totalColors) * 100) 
    : 100;
  (document.getElementById('statRate') as HTMLDivElement).textContent = `${rate}%`;

  // 결과 목록
  if (data.violations.length === 0) {
    results.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">✅</div>
        <div class="empty-title">완벽합니다!</div>
        <p>모든 색상이 Color Variables를 사용하고 있습니다.</p>
      </div>
    `;
    footer.style.display = 'none';
  } else {
    results.innerHTML = `
      <div class="results-header">
        <div class="results-title">
          ⚠️ 하드코딩된 색상
          <span class="results-count">(${data.violations.length}개)</span>
        </div>
      </div>
      ${data.violations.map(renderViolationItem).join('')}
    `;

    // 이벤트 리스너 연결
    attachEventListeners();

    // 푸터 표시
    footer.style.display = 'block';
    fixAllBtn.textContent = `✨ ${data.violations.filter(v => v.suggestion).length}개 색상 모두 수정`;
  }
}

function renderViolationItem(violation: ColorUsage): string {
  const familyClass = `family-${violation.family}`;
  const hasOpacity = violation.opacity < 1;

  return `
    <div class="violation-item" data-node-id="${violation.nodeId}">
      <div class="violation-header">
        <div class="color-swatch ${hasOpacity ? 'has-opacity' : ''}">
          <div class="color-swatch-inner" style="background-color: ${violation.hex}; opacity: ${violation.opacity}"></div>
        </div>
        <div class="violation-info">
          <div class="violation-color">
            <span class="color-hex">${violation.hex}</span>
            ${hasOpacity ? `<span class="color-hex" style="color: var(--text-tertiary)">${Math.round(violation.opacity * 100)}%</span>` : ''}
            <span class="color-family ${familyClass}">${violation.family}</span>
          </div>
          <div class="violation-node" data-node-id="${violation.nodeId}">
            ${escapeHtml(violation.nodeName)}
            <span class="property-badge">${violation.propertyType === 'fill' ? 'Fill' : 'Stroke'}</span>
          </div>
        </div>
      </div>
      ${violation.suggestion ? renderSuggestion(violation) : renderNoSuggestion()}
    </div>
  `;
}

function renderSuggestion(violation: ColorUsage): string {
  const suggestion = violation.suggestion!;
  
  return `
    <div class="suggestion">
      <span class="suggestion-arrow">→</span>
      <div class="suggestion-swatch" style="background-color: ${suggestion.hex}"></div>
      <div class="suggestion-info">
        <div class="suggestion-name">${suggestion.name}</div>
        <div class="suggestion-hex">${suggestion.hex}</div>
      </div>
      ${suggestion.distance > 0 ? `<span class="suggestion-distance">거리: ${suggestion.distance}</span>` : ''}
      <button class="btn-fix" 
        data-node-id="${violation.nodeId}"
        data-property-type="${violation.propertyType}"
        data-paint-index="${violation.paintIndex}"
        data-variable-id="${suggestion.variableId}">
        수정
      </button>
    </div>
  `;
}

function renderNoSuggestion(): string {
  return `
    <div class="suggestion" style="background: var(--bg-error);">
      <span class="suggestion-arrow">⚠️</span>
      <span style="color: var(--text-error); font-size: 11px;">
        추천할 수 있는 Variable이 없습니다
      </span>
    </div>
  `;
}

// ============================================
// 이벤트 리스너 연결
// ============================================

function attachEventListeners(): void {
  // 노드 선택
  results.querySelectorAll('.violation-node').forEach((el) => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const nodeId = (el as HTMLElement).dataset.nodeId;
      if (nodeId) {
        parent.postMessage({ 
          pluginMessage: { type: 'select-node', payload: { nodeId } } 
        }, '*');
      }
    });
  });

  // 개별 수정 버튼
  results.querySelectorAll('.btn-fix').forEach((el) => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const btn = el as HTMLElement;
      parent.postMessage({
        pluginMessage: {
          type: 'fix-color',
          payload: {
            nodeId: btn.dataset.nodeId,
            propertyType: btn.dataset.propertyType,
            paintIndex: parseInt(btn.dataset.paintIndex || '0'),
            variableId: btn.dataset.variableId,
          }
        }
      }, '*');
    });
  });
}

// ============================================
// 유틸리티
// ============================================

function escapeHtml(text: string): string {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
