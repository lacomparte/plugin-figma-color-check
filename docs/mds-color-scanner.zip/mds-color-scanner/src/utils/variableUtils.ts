// src/utils/variableUtils.ts

import { 
  ColorToken, 
  figmaRgbToHex, 
  determineColorFamily, 
  colorDistance 
} from './colorUtils';

/**
 * 로컬 Color Variables에서 SSOT 색상 토큰 로드
 */
export async function loadColorTokensFromVariables(): Promise<ColorToken[]> {
  const variables = await figma.variables.getLocalVariablesAsync('COLOR');
  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  
  const tokens: ColorToken[] = [];

  for (const variable of variables) {
    const collection = collections.find(c => c.id === variable.variableCollectionId);
    const modeId = collection?.defaultModeId;

    if (!modeId) continue;

    const value = variable.valuesByMode[modeId];

    // Variable Alias인 경우 실제 값 추적
    let resolvedValue = value;
    if (typeof value === 'object' && 'type' in value && (value as any).type === 'VARIABLE_ALIAS') {
      const aliasedVar = await figma.variables.getVariableByIdAsync((value as any).id);
      if (aliasedVar) {
        const aliasCollection = collections.find(c => c.id === aliasedVar.variableCollectionId);
        const aliasModeId = aliasCollection?.defaultModeId;
        if (aliasModeId) {
          resolvedValue = aliasedVar.valuesByMode[aliasModeId];
        }
      }
    }

    // RGBA 객체인 경우
    if (resolvedValue && typeof resolvedValue === 'object' && 'r' in resolvedValue) {
      const rgba = resolvedValue as RGBA;
      const rgb = {
        r: Math.round(rgba.r * 255),
        g: Math.round(rgba.g * 255),
        b: Math.round(rgba.b * 255),
      };

      tokens.push({
        variableId: variable.id,
        name: variable.name,
        hex: figmaRgbToHex(rgba.r, rgba.g, rgba.b),
        rgb,
        opacity: rgba.a ?? 1,
        family: determineColorFamily(rgb.r, rgb.g, rgb.b),
      });
    }
  }

  return tokens;
}

/**
 * 같은 색상 계열 내에서 가장 가까운 토큰 찾기
 */
export function findClosestToken(
  rgb: { r: number; g: number; b: number },
  tokens: ColorToken[],
  preferSameFamily: boolean = true
): ColorToken | null {
  const family = determineColorFamily(rgb.r, rgb.g, rgb.b);
  
  // 같은 계열 토큰 필터링
  let candidates = preferSameFamily 
    ? tokens.filter(t => t.family === family)
    : tokens;

  // 같은 계열에 토큰이 없으면 전체에서 검색
  if (candidates.length === 0) {
    candidates = tokens;
  }

  let closest: ColorToken | null = null;
  let minDistance = Infinity;

  for (const token of candidates) {
    const dist = colorDistance(rgb, token.rgb);
    if (dist < minDistance) {
      minDistance = dist;
      closest = token;
    }
  }

  return closest;
}

/**
 * 정확히 일치하는 토큰 찾기
 */
export function findExactToken(
  rgb: { r: number; g: number; b: number },
  opacity: number,
  tokens: ColorToken[],
  tolerance: number = 2
): ColorToken | null {
  for (const token of tokens) {
    const dist = colorDistance(rgb, token.rgb);
    const opacityMatch = Math.abs(token.opacity - opacity) < 0.01;
    
    if (dist <= tolerance && opacityMatch) {
      return token;
    }
  }
  return null;
}
