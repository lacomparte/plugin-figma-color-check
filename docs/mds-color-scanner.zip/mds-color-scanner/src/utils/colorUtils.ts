// src/utils/colorUtils.ts

/**
 * 색상 계열 타입
 */
export type ColorFamily = 'grayscale' | 'blue' | 'red' | 'yellow' | 'green' | 'other';

/**
 * SSOT 색상 토큰 인터페이스
 */
export interface ColorToken {
  variableId: string;
  name: string;
  hex: string;
  rgb: { r: number; g: number; b: number };
  opacity: number;
  family: ColorFamily;
}

/**
 * 검사 결과 인터페이스
 */
export interface ColorUsage {
  nodeId: string;
  nodeName: string;
  nodeType: string;
  propertyType: 'fill' | 'stroke';
  paintIndex: number;
  hex: string;
  rgb: { r: number; g: number; b: number };
  opacity: number;
  family: ColorFamily;
  isBoundToVariable: boolean;
  boundVariableName?: string;
  suggestion?: {
    variableId: string;
    name: string;
    hex: string;
    distance: number;
  };
}

/**
 * Figma RGB (0-1) → HEX 변환
 */
export function figmaRgbToHex(r: number, g: number, b: number): string {
  const toHex = (val: number) => 
    Math.round(val * 255).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}

/**
 * HEX → RGB (0-255) 변환
 */
export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16),
  } : null;
}

/**
 * 색상 계열 판단 (HSV 기반)
 */
export function determineColorFamily(r: number, g: number, b: number): ColorFamily {
  // 0-255 범위로 정규화
  const r255 = r > 1 ? r : Math.round(r * 255);
  const g255 = g > 1 ? g : Math.round(g * 255);
  const b255 = b > 1 ? b : Math.round(b * 255);

  const rNorm = r255 / 255;
  const gNorm = g255 / 255;
  const bNorm = b255 / 255;

  const max = Math.max(rNorm, gNorm, bNorm);
  const min = Math.min(rNorm, gNorm, bNorm);
  const delta = max - min;

  // 채도 계산
  const saturation = max === 0 ? 0 : delta / max;
  
  // 채도가 낮으면 무채색
  if (saturation < 0.1) {
    return 'grayscale';
  }

  // Hue 계산
  let hue = 0;
  if (delta !== 0) {
    if (max === rNorm) {
      hue = ((gNorm - bNorm) / delta) % 6;
    } else if (max === gNorm) {
      hue = (bNorm - rNorm) / delta + 2;
    } else {
      hue = (rNorm - gNorm) / delta + 4;
    }
  }
  hue = Math.round(hue * 60);
  if (hue < 0) hue += 360;

  // Hue 범위로 색상 계열 판단
  if ((hue >= 0 && hue < 15) || hue >= 345) return 'red';
  if (hue >= 15 && hue < 45) return 'yellow'; // 주황 포함
  if (hue >= 45 && hue < 75) return 'yellow';
  if (hue >= 75 && hue < 165) return 'green';
  if (hue >= 165 && hue < 195) return 'other'; // cyan
  if (hue >= 195 && hue < 270) return 'blue';
  if (hue >= 270 && hue < 345) return 'other'; // purple/magenta

  return 'other';
}

/**
 * 두 색상 간의 거리 계산 (유클리드 RGB)
 */
export function colorDistance(
  c1: { r: number; g: number; b: number },
  c2: { r: number; g: number; b: number }
): number {
  // 0-255 범위로 정규화
  const r1 = c1.r > 1 ? c1.r : Math.round(c1.r * 255);
  const g1 = c1.g > 1 ? c1.g : Math.round(c1.g * 255);
  const b1 = c1.b > 1 ? c1.b : Math.round(c1.b * 255);
  
  const r2 = c2.r > 1 ? c2.r : Math.round(c2.r * 255);
  const g2 = c2.g > 1 ? c2.g : Math.round(c2.g * 255);
  const b2 = c2.b > 1 ? c2.b : Math.round(c2.b * 255);

  return Math.sqrt(
    Math.pow(r1 - r2, 2) +
    Math.pow(g1 - g2, 2) +
    Math.pow(b1 - b2, 2)
  );
}

/**
 * 색상 계열 한글 이름
 */
export function getColorFamilyName(family: ColorFamily): string {
  const names: Record<ColorFamily, string> = {
    grayscale: 'Gray',
    blue: 'Blue',
    red: 'Red',
    yellow: 'Yellow',
    green: 'Green',
    other: 'Other',
  };
  return names[family];
}
